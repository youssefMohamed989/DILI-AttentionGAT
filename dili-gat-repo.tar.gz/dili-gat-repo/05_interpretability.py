"""
05_interpretability.py
Section 3.8. Extracts attention-pooling weights from the trained
single-model GAT and renders atom-level attribution maps (RDKit
similarity-map-style highlighting) for representative true-positive,
true-negative, false-positive, and false-negative test molecules.
"""
import os

import numpy as np
import torch
from rdkit.Chem.Draw import rdMolDraw2D

from common import CHECKPOINT_DIR, FIGURES_DIR
from dataset_io import load_graphs_and_labels
from gnn_model import DILI_GAT, collate_graphs


def normalize_per_molecule(alpha: np.ndarray, graph_index: np.ndarray) -> np.ndarray:
    """min-max normalize attention weights to [0, 1] within each molecule."""
    out = np.zeros_like(alpha)
    for g in np.unique(graph_index):
        mask = graph_index == g
        vals = alpha[mask]
        lo, hi = vals.min(), vals.max()
        out[mask] = (vals - lo) / (hi - lo) if hi > lo else 0.5
    return out


def draw_attribution(mol, atom_weights: np.ndarray, out_path: str, title: str = ""):
    atom_colors = {}
    cmap_lo = np.array([1.0, 1.0, 1.0])
    cmap_hi = np.array([0.85, 0.10, 0.10])
    for i, w in enumerate(atom_weights):
        color = tuple((cmap_lo + w * (cmap_hi - cmap_lo)).tolist())
        atom_colors[i] = color
    drawer = rdMolDraw2D.MolDraw2DCairo(400, 400)
    rdMolDraw2D.PrepareAndDrawMolecule(
        drawer, mol, highlightAtoms=list(range(mol.GetNumAtoms())),
        highlightAtomColors=atom_colors, highlightBonds=[],
    )
    drawer.FinishDrawing()
    with open(out_path, "wb") as f:
        f.write(drawer.GetDrawingText())


def main():
    test_graphs, test_labels, test_df = load_graphs_and_labels("test")

    model = DILI_GAT()
    model.load_state_dict(torch.load(os.path.join(CHECKPOINT_DIR, "gat_single_model.pt"),
                                      map_location="cpu"))
    model.eval()

    batch = collate_graphs(test_graphs)
    with torch.no_grad():
        logit, alpha = model(batch, return_attention=True)
    prob = torch.sigmoid(logit).numpy()
    alpha = alpha.numpy()
    graph_index = batch.graph_index.numpy()
    alpha_norm = normalize_per_molecule(alpha, graph_index)

    pred = (prob >= 0.5).astype(int)
    true = test_labels.astype(int)
    categories = {
        "true_positive": np.where((pred == 1) & (true == 1))[0],
        "true_negative": np.where((pred == 0) & (true == 0))[0],
        "false_positive": np.where((pred == 1) & (true == 0))[0],
        "false_negative": np.where((pred == 0) & (true == 1))[0],
    }

    os.makedirs(os.path.join(FIGURES_DIR, "attribution_maps"), exist_ok=True)
    summary = []
    for cat, idxs in categories.items():
        if len(idxs) == 0:
            continue
        # pick the most confidently-classified representative example
        conf = np.abs(prob[idxs] - 0.5)
        rep = idxs[np.argmax(conf)]
        mol = test_graphs[rep]["mol"]
        mask = graph_index == rep
        weights = alpha_norm[mask]
        out_path = os.path.join(FIGURES_DIR, "attribution_maps", f"{cat}.png")
        draw_attribution(mol, weights, out_path)
        summary.append({
            "category": cat, "test_index": int(rep),
            "predicted_prob": float(prob[rep]), "true_label": int(true[rep]),
            "image": out_path,
        })
        print(f"{cat}: idx={rep} pred_prob={prob[rep]:.3f} true={true[rep]} -> {out_path}")

    import json
    with open(os.path.join(FIGURES_DIR, "attribution_maps", "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)


if __name__ == "__main__":
    main()
